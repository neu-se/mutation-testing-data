# Report (Precomputed mutators)
| Project | #Prompts | #Mutants | #Killed | #Survived | #Timeout | MutationScore | LLMorpheus Time | Stryker Time | #Prompt Tokens | #Completion Tokens | #Total Tokens  |
|:--------|:---------|:---------|:--------|:----------|----------|---------------|-----------------|--------------|----------------|--------------------|----------------|
| Complex.js | 490 | 1200 | 726 | 473 | 1 | 60.58 | 3000.55 | 502.02 | 967508 | 102470 | 1069978 |
| countries-and-timezones | 106 | 217 | 188 | 29 | 0 | 86.64 | 1070.93 | 272.8 | 105828 | 23436 | 129264 |
| crawler-url-parser | 176 | 285 | 157 | 128 | 0 | 55.09 | 1641.99 | 622.88 | 386223 | 39202 | 425425 |
| delta | 462 | 765 | 634 | 99 | 32 | 87.06 | 2970.35 | 3437.24 | 890252 | 99064 | 989316 |
| image-downloader | 42 | 89 | 72 | 17 | 0 | 80.9 | 430.67 | 226.64 | 24655 | 9085 | 33740 |
| node-dirty | 154 | 275 | 196 | 69 | 10 | 74.91 | 1526.83 | 154.34 | 246248 | 33134 | 279382 |
| node-geo-point | 140 | 302 | 223 | 79 | 0 | 73.84 | 1411.25 | 886.33 | 316333 | 30027 | 346360 |
| node-jsonfile | 68 | 154 | 50 | 47 | 57 | 69.48 | 690.65 | 253.8 | 57516 | 14838 | 72354 |
| plural | 153 | 279 | 203 | 75 | 1 | 73.12 | 1521.31 | 117.53 | 265602 | 34138 | 299740 |
| pull-stream | 351 | 770 | 440 | 273 | 57 | 64.55 | 2477.35 | 760.88 | 208130 | 76560 | 284690 |
| q | 1051 | 2034 | 158 | 1792 | 84 | 11.9 | 5323.99 | 7165.22 | 2127655 | 220464 | 2348119 |
| spacl-core | 134 | 239 | 197 | 41 | 1 | 82.85 | 1351.03 | 714.94 | 162705 | 29306 | 192011 |
| zip-a-folder | 49 | 100 | 45 | 46 | 9 | 54 | 500.54 | 453.68 | 82457 | 10705 | 93162 |
| Total | 3376 | 6709 | 3289 | 3168 | 252 | - | 23917.44 | 15568.30 | 5841112 | 722429 | 6563541 |
## Experimental Parameters
  - Model: codellama-34b-instruct
  - Temperature: 0
  - Max Tokens: 250
  - Max Nr of Prompts: 2000
  - Template: template-full.hb
  - System Prompt: SystemPrompt-MutationTestingExpert.txt
  - Rate Limit: benchmark mode
  - Number of Attempts: 3


