# Report (StrykerJS standard mutators --concurrency 1)
| Project | #Mutants | #Killed | #Survived | #Timeout | MutationScore | Time |
|:--------|:---------|:--------|:----------|----------|---------------|------|
| Complex.js | 1302 | 763 | 539 | 0 | 58.6 | 687.01 |
| countries-and-timezones | 140 | 134 | 6 | 0 | 95.71 | 205.88 |
| crawler-url-parser | 226 | 143 | 83 | 0 | 63.27 | 739.58 |
| delta | 834 | 686 | 88 | 60 | 89.45 | 4200.75 |
| image-downloader | 43 | 28 | 11 | 4 | 74.42 | 299.72 |
| node-dirty | 160 | 78 | 56 | 26 | 65 | 267.33 |
| node-geo-point | 158 | 98 | 60 | 0 | 62.03 | 502.91 |
| node-jsonfile | 61 | 31 | 5 | 25 | 91.8 | 220.17 |
| plural | 180 | 143 | 37 | 0 | 79.44 | 92.9 |
| pull-stream | 474 | 318 | 116 | 40 | 75.53 | 834.18 |
| q | 1058 | 68 | 927 | 63 | 12.38 | 7516.19 |
| spacl-core | 259 | 239 | 20 | 0 | 92.28 | 813.55 |
| zip-a-folder | 74 | 38 | 8 | 28 | 89.19 | 604.29 |
| Total | 4969 | 2767 | 1956 | 246 | - | 16984.46 |

