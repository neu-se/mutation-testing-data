# Report (Precomputed mutators --concurrency 1)
| Project | #Prompts | #Mutants | #Killed | #Survived | #Timeout | MutationScore | LLMorpheus Time | Stryker Time | #Prompt Tokens | #Completion Tokens | #Total Tokens  |
|:--------|:---------|:---------|:--------|:----------|----------|---------------|-----------------|--------------|----------------|--------------------|----------------|
| Complex.js | 490 | 1199 | 725 | 473 | 1 | 60.55 | 3050 | 637.85 | 967508 | 102517 | 1070025 |
| countries-and-timezones | 106 | 217 | 188 | 29 | 0 | 86.64 | 1070.89 | 313.86 | 105828 | 23441 | 129269 |
| crawler-url-parser | 176 | 285 | 157 | 128 | 0 | 55.09 | 1642.7 | 929.43 | 386223 | 39175 | 425398 |
| delta | 462 | 767 | 634 | 101 | 32 | 86.83 | 2961.66 | 3839.6 | 890252 | 98974 | 989226 |
| image-downloader | 42 | 89 | 72 | 17 | 0 | 80.9 | 430.53 | 379.25 | 24655 | 9134 | 33789 |
| node-dirty | 154 | 275 | 163 | 100 | 12 | 63.64 | 1526.2 | 241.81 | 246248 | 33070 | 279318 |
| node-geo-point | 140 | 302 | 223 | 79 | 0 | 73.84 | 1411.11 | 987.17 | 316333 | 30013 | 346346 |
| node-jsonfile | 68 | 154 | 49 | 48 | 57 | 68.83 | 690.61 | 474.78 | 57516 | 14797 | 72313 |
| plural | 153 | 281 | 205 | 75 | 1 | 73.31 | 1521.32 | 155.24 | 265602 | 34174 | 299776 |
| pull-stream | 351 | 769 | 441 | 271 | 57 | 64.76 | 2492.5 | 1608.97 | 208130 | 76513 | 284643 |
| q | 1051 | 2035 | 158 | 1792 | 85 | 11.94 | 5241.46 | 14034.67 | 2127655 | 220215 | 2347870 |
| spacl-core | 134 | 239 | 199 | 39 | 1 | 83.68 | 1351.08 | 798.96 | 162705 | 29236 | 191941 |
| zip-a-folder | 49 | 100 | 23 | 3 | 74 | 97 | 500.57 | 1156.11 | 82457 | 10725 | 93182 |
| Total | 3376 | 6712 | 3237 | 3155 | 320 | - | 23890.63 | 25557.70 | 5841112 | 721984 | 6563096 |
## Experimental Parameters
  - Model: codellama-34b-instruct
  - Temperature: 0
  - Max Tokens: 250
  - Max Nr of Prompts: 2000
  - Template: template-full.hb
  - System Prompt: SystemPrompt-MutationTestingExpert.txt
  - Rate Limit: benchmark mode
  - Number of Attempts: 3


