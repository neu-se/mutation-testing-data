# Report (Precomputed mutators --concurrency 1)
| Project | #Prompts | #Mutants | #Killed | #Survived | #Timeout | MutationScore | LLMorpheus Time | Stryker Time | #Prompt Tokens | #Completion Tokens | #Total Tokens  |
|:--------|:---------|:---------|:--------|:----------|----------|---------------|-----------------|--------------|----------------|--------------------|----------------|
| Complex.js | 490 | 1136 | 695 | 440 | 1 | 61.27 | 3492.66 | 629 | 953788 | 104886 | 1058674 |
| countries-and-timezones | 106 | 218 | 174 | 44 | 0 | 79.82 | 1177.99 | 323.34 | 102860 | 23502 | 126362 |
| crawler-url-parser | 176 | 246 | 134 | 112 | 0 | 54.47 | 1751.37 | 786.06 | 381295 | 38800 | 420095 |
| delta | 462 | 759 | 612 | 115 | 32 | 84.85 | 3365.2 | 3872.79 | 877316 | 99562 | 976878 |
| image-downloader | 42 | 84 | 70 | 14 | 0 | 83.33 | 441.26 | 358.96 | 23479 | 8961 | 32440 |
| node-dirty | 154 | 260 | 147 | 102 | 11 | 60.77 | 1608.97 | 228.53 | 241936 | 33053 | 274989 |
| node-geo-point | 140 | 306 | 230 | 76 | 0 | 75.16 | 1492.54 | 1035.93 | 312413 | 28984 | 341397 |
| node-jsonfile | 68 | 148 | 45 | 51 | 52 | 65.54 | 717.49 | 465.56 | 55612 | 14548 | 70160 |
| plural | 153 | 262 | 189 | 72 | 1 | 72.52 | 1630.97 | 140.39 | 261318 | 34444 | 295762 |
| pull-stream | 351 | 779 | 464 | 249 | 66 | 68.04 | 2738.37 | 1433.35 | 198302 | 74222 | 272524 |
| q | 1051 | 1956 | 138 | 1725 | 93 | 11.81 | 6155.1 | 13521.99 | 2098227 | 218163 | 2316390 |
| spacl-core | 134 | 187 | 155 | 31 | 1 | 83.42 | 1440.32 | 585.59 | 158953 | 29512 | 188465 |
| zip-a-folder | 49 | 97 | 26 | 4 | 67 | 95.88 | 509.75 | 1063.09 | 81085 | 10694 | 91779 |
| Total | 3376 | 6438 | 3079 | 3035 | 324 | - | 26521.99 | 24444.58 | 5746584 | 719331 | 6465915 |
## Experimental Parameters
  - Model: codellama-34b-instruct
  - Temperature: 0
  - Max Tokens: 250
  - Max Nr of Prompts: 2000
  - Template: template-noinstructions.hb
  - System Prompt: SystemPrompt-MutationTestingExpert.txt
  - Rate Limit: benchmark mode
  - Number of Attempts: 3


